# .. this script should be run via "../master.R" 
# .. if you want to run this script directly, set working directory 
# .. "../codes_dmkd_glmdag/" and uncomment below
# source("./scripts/sub_master.R") 

table_name = "Table_H3.txt"
table_dir = paste0("./tables_figures/", table_name)

## set simulation environment
seed_para = 100
n_iters = 100
n_nodes = 30
n_obs_list = c(50, 200)
types_by_node = rep("m", n_nodes) # because all nodes are nominal-level
n_levels_by_node = gen_node_levels(types_by_node, 4, seed = seed_para)

## setup result table
empty_eval_table <- data.frame(P = double(), E = double(), TPR = double(),
                               JI = double(), R = double(), M = double(), 
                               FP = double(), FDP = double(), SHD = double())

## generate Table 2 

subdir_result = "./results_saved/simu1/simu1_n_"
write(x = "Number of Nodes: 30; Node-type: Multinomial (Nominal-Levels)", 
      file = table_dir, append = F)
write(x = "Number of Iterations: 100 for each set-up \n\n", 
      file = table_dir, append = T)

for (graph in graph_types){ # graph = "rand"
  
  cat("=====================\n")
  cat(paste0("graph = ", graph,"\n"))
  cat("=====================\n")
  
  graph_set = gen_graph_adj_mat(n_nodes, graph, seed = seed_para)
  graph_true = graph_set$graph_true
  A_true = graph_set$A_true
  W_true = gen_para(A_true, types_by_node, n_levels_by_node, seed = seed_para)
  n_edges = sum(A_true)

  eval_table_by_graph <- empty_eval_table
  
  for (n_obs in n_obs_list) { # n_obs = 50
    
    cat("------------\n")
    cat(paste0("n_obs = ", n_obs,"\n"))
    cat("------------\n")
    
    
    iter_table_glmdag <- empty_eval_table
    iter_table_cd <- empty_eval_table
    
    for (iter in seq_len(n_iters)){ # iter = 1
      
      cat(paste0("iter = ", iter,"\n"))
      
      data_input = gen_data(n_obs, A_true, graph_true, W_true, seed = iter)
      suppressMessages(data_input_cd <- conv_to_cd_data(data_input))
      
      if (use_saved_results){
        
        result_name = paste0(subdir_result, n_obs,"_", graph,"_", iter,".rds")
        result = readRDS(result_name)
        
        result_glmdag = result$glmdag
        result_cd = result$cd
        
      } else {
        
        result_glmdag = glmdag(data_input, verbose = T)
        result_cd = cd.run(indata = data_input_cd)
        
      }
      
      temp_eval_glmdag = eval_by_lam(result_glmdag$pushed_A_est_by_lam,
                                     A_true, n_edges, type = "obs")
      temp_sel_glmdag = mod_sel(temp_eval_glmdag, n_edges, sel_crit = "JI")
      iter_table_glmdag = rbind(iter_table_glmdag, temp_sel_glmdag)
      
      A_est_by_lam_cd = calc_A_est_by_lam_cd(result_cd)
      temp_eval_cd = eval_by_lam(A_est_by_lam_cd, A_true, n_edges, type="obs")
      temp_sel_cd = mod_sel(temp_eval_cd, n_edges, sel_crit = "JI")
      iter_table_cd = rbind(iter_table_cd, temp_sel_cd)
      
    } # end of iter
    
    ave_iter_table_glmdag <- colMeans(iter_table_glmdag) %>% round(digits = 2)
    eval_table_by_graph = rbind(eval_table_by_graph, ave_iter_table_glmdag)
    
    ave_iter_table_cd <- colMeans(iter_table_cd) %>% round(digits = 2)
    eval_table_by_graph = rbind(eval_table_by_graph, ave_iter_table_cd)
    
    
  } # end of n_obs
  
  row_names = paste(rep(c("glmdag (n=", "    cd (n=" ), times = 2), 
                    rep(c(" 50)", "200)"), each = 2), sep ="")
  row.names(eval_table_by_graph ) <- row_names
  
  colnames(eval_table_by_graph)<-c("P","E","TPR","JI","R*","M","FP","FDP","SHD")
  
  graph_name = graph_types_long[which(graph_types == graph)]
  
  write(paste(graph_name, ": n_edges = ", sum(A_true), "\n"),
        file =  table_dir, append = T)
  
  sink(file = table_dir, append = T)
  print(eval_table_by_graph)
  sink()
  
  write("\n\n", file = table_dir, append = T)

} # end of graph