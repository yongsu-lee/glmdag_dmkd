# .. this script should be run via "../master.R" 
# .. if you want to run this script directly, set working directory 
# .. "../codes_dmkd_glmdag/" and uncomment below
# source("./scripts/sub_master.R") 

table_name = "Table_H4.txt"
table_dir = paste0("./tables_figures/", table_name)

## set simulation environment
seed_para = 100
n_iters = 100
n_obs = 50
thre_idx = 6 

n_multi = 4
n_conti = 6
n_ordin = 0 
n_nodes = n_multi + n_conti + n_ordin
method_list = c("mc", "mm", "mo", "hc", "mmhc")

types_by_node = gen_node_types(n_conti, n_multi, n_ordin, seed = seed_para)
n_levels_by_node = gen_node_levels(types_by_node, 4, seed = seed_para)

## setup result table
empty_eval_table <- data.frame(P = double(), E = double(), TPR = double(),
                               JI = double(), R = double(), M = double(), 
                               FP = double(), FDP = double(), SHD = double())

## generate Table 3

subdir_result = "./results_saved/simu2_small/simu2_small_"
write(x="Number of Nodes: 10, Node-type: Mixed (nominal nodes + ordinal nodes)", 
      file = table_dir, append = F)
write(x = paste0("Number of Iterations: ", n_iters, " for each set-up \n"), 
      file = table_dir, append = T)

for (graph in graph_types){ # graph = "rand"
  
  cat("=====================\n")
  cat(paste0("graph = ", graph,"\n"))
  cat("=====================\n")
  
  graph_set = gen_graph_adj_mat(n_nodes, graph, seed = seed_para)
  graph_true = graph_set$graph_true
  A_true = graph_set$A_true
  W_true = gen_para(A_true, types_by_node, n_levels_by_node, seed = seed_para)
  n_edges = sum(A_true)
  
  iter_table = empty_eval_table 
  mc_table = mo_table = mm_table = hc_table = mmhc_table <- empty_eval_table
  
  for (iter in seq_len(n_iters)){ # iter = 1
    
    cat("--------------------\n")
    cat(paste0("iter = ", iter,"\n"))
    cat("--------------------\n")
    
    data_input = gen_data(n_obs, A_true, graph_true, W_true, seed = iter)
    
    ## pick continuous nodes to be discretized (not necessary for small case)
    disc_nodes = which(types_by_node == "c")
    n_disc = length(disc_nodes)
    five_level_nodes = disc_nodes[1:n_disc] # not necessary for five-level only
    
    ## Discretizing into 5 levels
    temp = data_input[five_level_nodes]
    temp2 = lapply(temp, function(x) 
      cut(x, c(min(x)-1, quantile(as.matrix(x), probs = c(0.2,0.4,0.6,0.8,1))), 
          labels = 1:5))
    discretized_data = data.frame(temp2)
    
    for (method in method_list){ # method = "hc"
      
      cat("+++++++++++++++++\n")
      cat(paste0("method = ", method,"\n"))
      
      data_input = 
        switch(method,
               "mc" = { data_input },
               "mo" = { 
                 ordered = lapply(discretized_data,  
                                  function(x) factor(x, ordered = T))
                 data_input[disc_nodes] <- ordered; data_input},  
               # default case: "mm", "mmhc", "hc"
               { data_input[disc_nodes] <- discretized_data; data_input }
        )
      
      if (use_saved_results){
        
        if (method %in% c("mc","mo","mm")){
          result_name = paste0(subdir_result,graph,"_",method,"_",iter,".rds")
          result = readRDS(result_name)
          
          A_est = result$pushed_A_est_by_lam
          sel_lam = result$sel_tun
          single = FALSE
          
        } else {
          result_name = paste0(subdir_result, graph,"_mmhc_", iter,".rds")
          result.temp = readRDS(result_name)
          
          if (method == "mmhc"){ 
            result = result.temp$mmhc
          } else { result = result.temp$hc }
          
          A_est = amat(result)
          single = TRUE
          
        }
        
      } else {
        
        if (method %in% c("mc","mo","mm")){
          result = glmdag(data_input, verbose = T)
          A_est = result$pushed_A_est_by_lam
          sel_lam = result$sel_tun
          
        } else {
          if (method == "mmhc"){result=mmhc(data_input)
          } else {result=hc(data_input)}
          
          A_est = amat(result)
          single = TRUE
          
        }
        
      } # end of use_saved_results
      
      if (method == "mc") {
        mc_table[iter,] <- 
          eval_table(A_est, A_true, "obs", sel_lam)[thre_idx,-c(10,11)]
      } else if (method == "mo"){
        mo_table[iter,] <- 
          eval_table(A_est, A_true, "obs", sel_lam)[thre_idx,-c(10,11)]
      } else if (method == "mm"){
        mm_table[iter,] <- 
          eval_table(A_est, A_true, "obs", sel_lam)[thre_idx,-c(10,11)]
      } else if (method == "mmhc"){
        mmhc_table[iter,] <- eval_table(A_est, A_true, "obs", single = single)
      } else {
        hc_table[iter,] <- eval_table(A_est, A_true, "obs", single = single)
      }
      
    } # end of method
    
  } # end of iter
  
  ave_mc_table <- colMeans(mc_table) %>% round(digits = 2)
  ave_mo_table <- colMeans(mo_table) %>% round(digits = 2)
  ave_mm_table <- colMeans(mm_table) %>% round(digits = 2)
  ave_mmhc_table <- colMeans(mmhc_table) %>% round(digits = 2)
  ave_hc_table <- colMeans(hc_table) %>% round(digits = 2)
  
  eval_table_by_graph = rbind(ave_mc_table, ave_mo_table, ave_mm_table, 
                              ave_hc_table, ave_mmhc_table)
  
  row_names = c("glmdag:mc", "glmdag:mo", "glmdag:mm", 
                "hc    :mm", "mmhc  :mm")
  row.names(eval_table_by_graph) <- row_names
  
  colnames(eval_table_by_graph)<-c("P","E","TPR","JI","R*","M","FP","FDP","SHD")
  
  graph_name = graph_types_long[which(graph_types == graph)]
  
  write(paste(graph_name, ": n_edges = ", sum(A_true), "\n"),
        file =  table_dir, append = T)
  
  sink(file = table_dir, append = T)
  print(eval_table_by_graph)
  sink()
  
  write("\n\n", file = table_dir, append = T)
  
} # end of graph