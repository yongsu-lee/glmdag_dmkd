# .. this script should be run via "../master.R" 
# .. if you want to run this script directly, set working directory 
# .. "../codes_dmkd_glmdag/" and uncomment below
# source("./scripts/sub_master.R") 

table_name = "Table_H5.txt"
table_dir = paste0("./tables_figures/", table_name)

## set simulation environment
seed_para = 100
n_iters = 100
n_obs = 150
n_lams = 30 # number of tuning parameters 
thre_idx = 6 

n_multi = 15
n_conti = 10
n_ordin = 25 
n_nodes = n_multi + n_conti + n_ordin
method_list = c("mcc", "mcm", "mco", "hc", "mmhc")

types_by_node = gen_node_types(n_conti + n_ordin, n_multi, 0, seed = seed_para)
n_levels_by_node = gen_node_levels(types_by_node, 4, seed = seed_para)

## setup result table
empty_eval_table <- data.frame(P = double(), E = double(), TPR = double(),
                               JI = double(), R = double(), M = double(), 
                               FP = double(), FDP = double(), SHD = double())

## generate Table 4

subdir0 = "./results_saved/simu2_large/"
write(x=paste0("Number of Nodes: 50, Node-type:", 
               "Mixed (nominal nodes + ordinal nodes + continuous noes)"), 
      file = table_dir, append = F)
write(x = paste0("Number of Iterations: ", n_iters, " for each set-up \n"), 
      file = table_dir, append = T)

for (graph in graph_types){ # graph = "tree"
  
  init_file_name = paste0("simu2_large_", graph, "_")
  subdir1 = paste0(subdir0, graph, "/")
  
  cat("=====================\n")
  cat(paste0("graph = ", graph,"\n"))
  cat("=====================\n")
  
  graph_set = gen_graph_adj_mat(n_nodes, graph, seed = seed_para)
  graph_true = graph_set$graph_true
  A_true = graph_set$A_true
  W_true = gen_para(A_true, types_by_node, n_levels_by_node, seed = seed_para)
  n_edges = sum(A_true)

  mcc_table = mco_table = mcm_table = hc_table = mmhc_table <- empty_eval_table
  
  for (iter in seq_len(n_iters)){ # iter = 1
    
    cat("--------------------\n")
    cat(paste0("iter = ", iter,"\n"))
    cat("--------------------\n")
    
    A_est_by_lam = as.list(rep(NA, n_lams))
    attr(A_est_by_lam, "n_edges") = rep(NA, n_lams)
    Beta_est_by_lam = as.list(rep(NA, n_lams))
    
    data_input = gen_data(n_obs, A_true, graph_true, W_true, seed = iter)
    
    ## pick continuous nodes to be discretized (not necessary for small case)
    disc_nodes = sample(which(types_by_node == "c"), n_ordin, replace = F)
    n_disc = length(disc_nodes)
    five_level_nodes = disc_nodes[1:n_disc] # not necessary for five-level only
    
    ## Discretizing into 5 levels
    temp = data_input[five_level_nodes]
    temp2 = lapply(temp, function(x) 
      cut(x, c(min(x)-1, quantile(as.matrix(x), probs = c(0.2,0.4,0.6,0.8,1))), 
          labels = 1:5))
    
    discretized_data = data.frame(temp2)
    
    for (method in method_list){ # method = "mmhc"
      
      m_temp = ifelse(method %in% c("mcc","mco", "mcm"), method, "mcm")
                            
      subdir2 = paste0(subdir1, m_temp, "/")
      
      cat("+++++++++++++++++\n")
      cat(paste0("method = ", method,"\n"))
      
      data_input = 
        switch(method,
               "mcc" = { data_input },
               "mco" = { 
                 ordered = lapply(discretized_data,  
                                  function(x) factor(x, ordered = T))
                 data_input[disc_nodes] <- ordered; data_input},  
               # default case: "mcm", "mmhc", "hc"
               { data_input[disc_nodes] <- discretized_data; data_input }
        )
      
      for (ell in 1:n_lams){ # ell = 1
        
        if ( (method %in% c("mmhc", "hc") ) & (ell != 1) ) break   
        
        cat(paste0("-- ell = ", ell, " --\n"))
        
        if (use_saved_results){
          
          if (method %in% c("mcc","mco","mcm")){
            result_name = paste0(subdir2, init_file_name, 
                                 method, "_", iter, "_", ell, ".rds")
            result = readRDS(result_name)
          } else {
            result_name = paste0(subdir2, init_file_name, "mmhc_", iter, ".rds")
            result.temp = readRDS(result_name)
            
            if (method == "mmhc"){ 
              result = result.temp$mmhc
            } else { result = result.temp$hc }
          }
          
        } else {
          
          if (method %in% c("mcc","mco","mcm")){
            result = glmdag(data_input, verbose = T, 
                            path_par = T, path_par_num = ell)
          } else { 
            if (method == "mmhc"){ 
              result = mmhc(data_input)
            } else { result = hc(data_input) }
          }
          
        } # end of use_saved_results
        
        if (method %in% c("mcc","mco","mcm")) {
          A_est_by_lam[[ell]] = result$pushed_A_est_by_lam[[1]] 
          attr(A_est_by_lam, "n_edges")[ell] = 
            attr(result$pushed_A_est_by_lam, "n_edges")
          Beta_est_by_lam[[ell]] = result$pushed_Beta_est_by_lam[[1]]
          if (ell == 1) data_info = result
        } else {
          A_est = amat(result)
          single = TRUE
        }
        
      } # end of ell
      
      if (method %in% c("mcc","mco","mcm")) {
        sel_lam = tun_sel_lkhd(A_est_by_lam, Beta_est_by_lam, data_info)
      } 
      
      if (method == "mcc") {
        mcc_table[iter,] <- 
          eval_table(A_est_by_lam, A_true, "obs", sel_lam)[thre_idx,-c(10,11)]
      } else if (method == "mco"){
        mco_table[iter,] <- 
          eval_table(A_est_by_lam, A_true, "obs", sel_lam)[thre_idx,-c(10,11)]
      } else if (method == "mcm"){
        mcm_table[iter,] <- 
          eval_table(A_est_by_lam, A_true, "obs", sel_lam)[thre_idx,-c(10,11)]
      } else if (method == "mmhc"){
        mmhc_table[iter,] <- eval_table(A_est, A_true, "obs", single = single)
      } else {
        hc_table[iter,] <- eval_table(A_est, A_true, "obs", single = single)
      }
      
    } # end of method
    
  } # end of iter
  
  ave_mcc_table <- colMeans(mcc_table) %>% round(digits = 2)
  ave_mco_table <- colMeans(mco_table) %>% round(digits = 2)
  ave_mcm_table <- colMeans(mcm_table) %>% round(digits = 2)
  ave_mmhc_table <- colMeans(mmhc_table) %>% round(digits = 2)
  ave_hc_table <- colMeans(hc_table) %>% round(digits = 2)
  
  eval_table_by_graph = rbind(ave_mcc_table, ave_mco_table, ave_mcm_table, 
                              ave_hc_table, ave_mmhc_table)
  
  row_names = c("glmdag:mcc", "glmdag:mco", "glmdag:mcm", 
                "hc    :mcm", "mmhc  :mcm")
  row.names(eval_table_by_graph) <- row_names
  
  colnames(eval_table_by_graph)<-c("P","E","TPR","JI","R*","M","FP","FDP","SHD")
  
  graph_name = graph_types_long[which(graph_types == graph)]
  
  write(paste(graph_name, ": n_edges = ", sum(A_true), "\n"),
        file =  table_dir, append = T)
  
  sink(file = table_dir, append = T)
  print(eval_table_by_graph)
  sink()
  
  write("\n\n", file = table_dir, append = T)
  
} # end of graph
