# .. This script includes codes necessary to run figure/table script 
# .. separately without using 'master.R' script. 

rm(list=ls())
RNGkind("Mersenne-Twister", "Inversion", "Rejection")
use_saved_results = 1
if (dir.exists("./results")){
  if (length(list.files("./results")) > 0) 
    invisible(file.remove(paste0("./results/", list.files("./results"))))
} else {
  dir.create("./results")
}

source("./scripts/00_load_r_pkgs.R")
subdir = "./scripts/"
source("./scripts/00_load_ftns.R")
graph_types_long = 
  c("Bipartite", "Random DAG", "Scale-Free", "Small-World", "Tree")
graph_types = c("bi","rand","sf","sw","tree")
