# for general purpose
if(!require(tidyverse)){
  install.packages("tidyverse", quiet = T)
  library(tidyverse, quietly = T)
}

if(!require(Matrix)){
  install.packages("Matrix", quiet = T)
  library(Matrix, quietly = T)
}

if(!require(expm)){
  install.packages("expm", quiet = T)
  library(expm, quietly = T)
}


## generate/extract graph-related information
if(!require(igraph)){
  install.packages("igraph", quiet = T)
  library(igraph, quietly = T)
}


## boosting algorithm 
Sys.sleep(1)
if(!require(Rcpp)){
  install.packages("Rcpp", quiet = T)
  library(Rcpp, quietly = T)
}

Sys.sleep(1)
if(!require(RcppArmadillo)){
  install.packages("RcppArmadillo", quiet = T)
  library(RcppArmadillo, quietly = T)
}

if(!require(lbfgs)){
  install.packages("lbfgs", quiet = T)
  library(lbfgs, quietly = T)
}


## for cd methods (simu1)
if(!require(discretecdAlgorithm)){
  install.packages("discretecdAlgorithm", quiet = T)
  library(discretecdAlgorithm, quietly = T)
}

if(!require(sparsebn)){
  install.packages("sparsebn", quiet = T)
  library(sparsebn, quietly = T)
}


## for hc, mmhc methods (simu2)
if(!require(bnlearn)){
  install.packages("bnlearn", quiet = T)
  library(bnlearn, quietly = T)
}


## imputing missing values (for hcc data)
if(!require(bnstruct)){
  install.packages("bnstruct", quiet = T)
  library(bnstruct, quietly = T)
}

# Deprecation -------------------------------------------------------------

# if(!require(VGAM)){
#   install.packages("VGAM", quiet = T)
#   library(VGAM, quietly = T)
# }

# if(!require(nnet)){
#   install.packages("nnet", quiet = T)
#   library(nnet, quietly = T)
# }


