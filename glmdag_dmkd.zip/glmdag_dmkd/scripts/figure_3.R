# .. this script should be run via "../master.R" 
# .. if you want to run this script directly, set working directory 
# .. "../codes_dmkd_glmdag/" and uncomment below
# source("./scripts/sub_master.R") 

fig_name = "Fig3.pdf"
fig_dir = paste0("./tables_figures/", fig_name)

## set simulation environment
seed_para = 100

n_multi = 4
n_conti = 6
n_ordin = 0 
n_nodes = n_multi + n_conti + n_ordin
types_by_node = gen_node_types(n_conti, n_multi, n_ordin, seed = seed_para)
# .. Figure 3 is for the simulation in Sec 5.3.1, 

## set plot layout parameters
m = c(1,1,2,2,3,3,1,1,2,2,3,3,0,4,4,5,5,0,0,4,4,5,5,0)
M = matrix(m, nrow =4, ncol = 6, byrow = T); layout(mat = M)

## draw graphs
pdf(fig_dir, width = 10)
layout(mat = M); par(mar=c(0,0.5,3,0.5)); par(oma=c(0,0,0,0))

for (j in seq_along(graph_types)){ # j =1
  
  graph_type = graph_types[j]
  graph_name = graph_types_long[j]
  
  graph_set = gen_graph_adj_mat(n_nodes, graph_type, seed = seed_para)
  graph_true = graph_set$graph_true
  A_true = graph_set$A_true
  
  fancy_dag_plot(A_true, types_by_node, title = graph_name,
                 edge.arrow.size = 0.3,
                 edge.color = "black",
                 vertex.label.cex = 2,
                 vertex.label.color = "white",
                 vertex.label.font = 2,
                 vertex.shape = "circle",
                 vertex.size = 17,
                 layout = layout_set(graph_true, graph_type))
}
dev.off()
# .. Check "./results/Fig3.pdf".

