# .. this script should be run via "../master.R" 
# .. if you want to run this script directly, set working directory 
# .. "../codes_dmkd_glmdag/" and uncomment below
# source("./scripts/sub_master.R") 

## Import dataset

# Get hcc dataset from UCI ML Repository
url = paste0("https://archive.ics.uci.edu/ml/machine-learning-databases/00423/",
             "hcc-survival.zip")
download.file(url, destfile = file.path("./data/.", basename(url)))
unzip(zipfile = "./data/hcc-survival.zip", exdir = "./data/.")
file.copy("./data/hcc-survival/hcc-data.txt", "./data/.")

# Delete 
unlink("./data/hcc-survival.zip")
if (Sys.info()['sysname'] == "Darwin")
  unlink("./data/__MACOSX/", recursive = T) # if your system is macOS
unlink("./data/hcc-survival/", recursive = T)

# read original data
hcc_temp <- read.table("./data/hcc-data.txt", sep=",", na.strings = "?")
n = nrow(hcc_temp)
hcc_temp_b4_impute = as.matrix(hcc_temp)

# Export the original data with xlsx format
hcc_info <- read.csv("./data/hcc_info.csv") 
var_names = hcc_info$var_names
names(hcc_temp) <- var_names


## Data cleaning
source("./scripts/hcc_cleaning.R") # See details in "./codes/hcc_cleaning.R"
data_input = hcc_imputed
var_names_modified = names(data_input)
write.csv(hcc_imputed, "./data/hcc_imputed.csv") # save the final data


## Run GLMDAG
# Set some parameters and containers
terminal_nodes = c("class")
root_nodes = c("gend", "ende", "age")
n_lams = 30 
graph_est_by_lam = as.list(rep(NA,n_lams))
A_est_by_lam = as.list(rep(NA,n_lams))
attr(A_est_by_lam, "n_edges") <- c()
Beta_est_by_lam = A_est_by_lam

# Learning GLMDAG using hcc data
# .. Note that we parallelzing the algorithm along with paths.
for (ell in 1:n_lams){ # ell = 1
  
  if(use_saved_results){
    result_file_name = paste0("./results_saved/hcc/hcc_",ell,".rds")
    result = readRDS(file = result_file_name)
    
  } else {
    result = glmdag(data_input, n_lams = n_lams, eps_lam = 0.1,
                    root_nodes = root_nodes, terminal_nodes = terminal_nodes,
                    path_par = T, path_par_num = ell, verbose = T)
  }
  
  graph_est_by_lam[[ell]] <- result$graph_est_by_lam[[1]]
  A_est_by_lam[[ell]] <- result$pushed_A_est_by_lam[[1]]
  attr(A_est_by_lam, "n_edges")[ell] <-  
    attr(result$pushed_A_est_by_lam, "n_edges")
  Beta_est_by_lam[[ell]] <- result$pushed_Beta_est_by_lam[[1]]
  if (ell == 1) data_info = result
  
}

sel_lam = tun_sel_lkhd(A_est_by_lam, Beta_est_by_lam, data_info)[6]
# .. We choose 22th path according to the threshold (gamma) = 0.5


## Drawing Graphs

# Excluding isolated nodes (no child and no parent)
A_est_reduced = A_est_by_lam[[sel_lam]]
combined = cbind(colSums(A_est_reduced), rowSums(A_est_reduced))
sig_nodes = rowSums(combined) !=0

# Save the modified graph
A_est_reduced = A_est_reduced[sig_nodes, sig_nodes]
graph_est_reduced = graph_from_adjacency_matrix(A_est_reduced)
var_names_reduced = var_names_modified[sig_nodes]

# Set colors of nodes according to data types
node_types = sapply(hcc_imputed, class)
node_types_reduced = node_types[var_names_reduced]
nodes_colors_reduced = sapply(node_types_reduced, function(x) {
  if ( any(x %in% "numeric") ) {
    "chartreuse4" # green
  } else if (any(x %in% "ordered")) {
    "dodgerblue3" # blue
  } else{
    "firebrick1" # red
  } })

# Set root nodes as "square" nodes (otherwise "circle")
nodes_shapes = ifelse(colSums(A_est_reduced) == 0, "square", "circle")

# Set direct factors' edges as "red" (otherwise "black")
edges_info = as_edgelist(graph_est_reduced)
target.num = which(var_names_reduced == "class")
direct.factors <- which(edges_info[,2] == target.num)
edges_colors = rep("black", nrow(edges_info))
edges_colors[direct.factors] <- "red"

# Generate graph 
pdf("./tables_figures/Fig6.pdf")
par(mar=c(0,0,0,0))
plot(graph_est_reduced, 
     edge.arrow.size=0.4,
     edge.color = edges_colors,
     edge.width = 1, 
     layout = layout_on_grid, 
     vertex.label = var_names_reduced, 
     vertex.label.cex = rep(0.8,50),
     vertex.label.color = "white",
     vertex.label.family = "Helvetica",
     vertex.color = nodes_colors_reduced,
     vertex.shape = nodes_shapes,
     vertex.size = 13)
dev.off()
# .. Note that it is the 'Figure 6' because it will be shown in Appendix.
# .. Check "./results/Fig6.pdf".


## Modified graph for the trimmed version

# Find all the non-descedents of the target (class)
A.df = as.data.frame(A_est_reduced)
non.desc = nrow(A.df) # class node
temp = non.desc 
while (length(temp) > 0){
  temp1 = lapply(A.df[,temp, drop = F], function(x) which(x != 0) )
  temp = unique(unlist(temp1))
  non.desc <- unique(c(temp, non.desc))
}
var_names_trimmed <- var_names_reduced[non.desc]

# Set the position of 16 nodes
## > var_names_trimmed
## [1] "nodules" "afp"     "ps"      "ggt"     "hemo"    "major"   "albu"   
## [8] "hbcab"   "hcvab"   "age"     "alch"    "asc"     "alt"     "ast"    
## [15] "ferr"    "class"  


A_est_trimmed <- A_est_reduced[non.desc, non.desc]
graph_est_trimmed <-  graph_from_adjacency_matrix(A_est_trimmed )

# Set colors of nodes according to data types
node_types = sapply(hcc_imputed, class)
node_types_trimmed = node_types[var_names_trimmed]
nodes_colors = sapply(node_types_trimmed, function(x) {
  if ( any(x %in% "numeric") ) {
    "chartreuse4" # green
  } else if (any(x %in% "ordered")) {
    "dodgerblue3" # blue
  } else{
    "firebrick1" # red
  } })

# Set root nodes as "square" nodes (otherwise "circle")
nodes_shapes = ifelse(colSums(A_est_trimmed) == 0, "square", "circle")

# Set direct factors' edges as "red" (otherwise "black")
edges_info = as_edgelist(graph_est_trimmed)
target.num = which(var_names_trimmed == "class")
direct.factors <- which(edges_info[,2] == target.num)
edges_colors = rep("black", nrow(edges_info))
edges_colors[direct.factors] <- "red"

# Set nodes' coordinates for better illustration
layout_info <- c(
-1.5, 0.5, # ps
 2.7, 0.7, # nodules
-3  , 1.2, # hemo
 1.5, 1, # afp
-2.5, 2  , # albu
 1.2, 2.5, # age
 2.5, 2  , # ggt
-1  , 1.5, # asc
 1.2, 2  , # alt
 0  , 2  ,# ast
 0  , 1.2, # ferr
 0  , 0  # class
)
layout_info <- matrix(layout_info, ncol = 2, byrow = T)
# ## > data.frame (var = var_names_trimmed, layout_info) # check coordinates

# Generate graph
pdf("./tables_figures/Fig5.pdf")
par(mar=c(0,0,0,0))
plot(graph_est_trimmed,
     edge.arrow.size = 0.4, 
     edge.color = edges_colors,
     layout = layout_info,
     vertex.color = nodes_colors,
     vertex.label.family = "Helvetica",
     vertex.shape = nodes_shapes,
     vertex.label = var_names_trimmed, 
     vertex.label.cex= rep(1.2,length(var_names_trimmed)),
     vertex.label.color = "white",
     vertex.size = 30 )
dev.off()