# Last Updated: Feb 2, 2021
# Set working direction to "codes_dmkd_glmdag" directory.
# Outputs will be generated in the "results" directory.

## clear the memory and set seed generating system
rm(list=ls())
# setwd("./glmdag_dmkd/")
RNGkind("Mersenne-Twister", "Inversion", "Rejection")


## Using saved results for reproduce tables/figures in the table
use_saved_results = TRUE

# .. Our simulation/application deals with large-size network. 
# .. Thus, without using parallel working (e.g., HTC), it takes a long time to
# .. obtain the final result. (Also, we consider 100 iterations for all cases.)
# .. Therefore, we strongly recommend to use the option 'use_saved_result=T',
# .. which directly download *.rds files from the github. 

# .. In order to use the saved results, you need to download files from github 
# .. and locate those files under "./glmdag_dmkd/results_saved". 
# .. See "README.pdf" for the details. 


## delete previous files in "./tables_figures/" if any
if (dir.exists("")){
  if (length(list.files("./tables_figures")) > 0) 
    invisible(file.remove(paste0("./tables_figures/", list.files("./tables_figures"))))
} else {
  dir.create("tables_figures")
}


## install and load necessary packages
source("./scripts/00_load_r_pkgs.R")


## load required functions (need compiling tools)
subdir = "./scripts/"
source("./scripts/00_load_ftns.R")


## various graph types
graph_types_long = 
  c("Bipartite", "Random DAG", "Scale-Free", "Small-World", "Tree")
graph_types = c("bi","rand","sf","sw","tree")


## Table 2 (Table, nominal-level only - 30 nodes) ####
source("./scripts/table_2.R")

## Table 3 (Table, mixed case (small) - 50 nodes) ####
source("./scripts/table_3.R")

## Table 4 (Table, mixed case (large) - 10 nodes) ####
source("./scripts/table_4.R")


## Figure 2 (Graphs, nominal-level only - 30 nodes) ####
source("./scripts/figure_2.R")

## Figure 3 (Graphs, mixed case (small) - 10 nodes) ####
source("./scripts/figure_3.R")

## Figure 4 (Graphs, mixed case (large) - 50 nodes) ####
source("./scripts/figure_4.R")

## Figure 5 and Figure 6 (Graph, HCC original and trimmed graph) ####
source("./scripts/figure_5_and_6.R")
