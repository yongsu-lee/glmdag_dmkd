# Last Updated: Dec 9, 2021
# Set working direction to "codes_dmkd_glmdag" directory.
# Outputs will be generated in the "results" directory.

## clear the memory and set seed generating system
rm(list=ls())
# setwd("./glmdag_dmkd/")
RNGkind("Mersenne-Twister", "Inversion", "Rejection")

## Using saved results for reproduce tables/figures in the table
use_saved_results = TRUE
if(use_saved_results){
  
  # simu_saved dir exist? otherwise download ... 
  url = paste0("https://github.com/yongsu-lee/glmdag_results_saved/",
               "archive/refs/heads/master.zip")
  download.file(url, destfile = file.path("./.", basename(url)))
  # .. 911.6 MB, it might take a while according to your internet status.
  if (!dir.exists("./results_saved")) dir.create("results_saved")
  zip.file = list.files()[grep("zip", list.files())] # master.zip
  unzip(zipfile = zip.file, exdir = "./results_saved/.")
  # .. unzipping saved simulation files. it might take a while. 
  file.copy("./results_saved/glmdag_results_saved-master/.", "./results_saved/.",
            recursive = T)
  unlink("./results_saved/glmdag_results_saved-master/", recursive = T)
}
# .. Our simulation/application deals with large-size network. 
# .. Thus, without using parallel working (e.g., HTC), it takes a long time to
# .. obtain the final result. (Also, we consider 100 iterations for all cases.)
# .. Therefore, we strongly recommend to use the option 'use_saved_result=T',
# .. which directly download *.rds files from the github. 

## delete previous files in "./tables_figures/" if any
if (dir.exists("")){
  if (length(list.files("./tables_figures")) > 0) 
    invisible(file.remove(paste0("./tables_figures/", list.files("./tables_figures"))))
} else {
  dir.create("tables_figures")
}

## install and load necessary packages
source("./scripts/00_load_r_pkgs.R")

## load required functions
subdir = "./scripts/"
source("./scripts/00_load_ftns.R")

## various graph types
graph_types_long = 
  c("Bipartite", "Random DAG", "Scale-Free", "Small-World", "Tree")
graph_types = c("bi","rand","sf","sw","tree")

## Table H3 (Table, nominal-level only - 30 nodes) ####
source("./scripts/table_h3.R")

## Table H4 (Table, mixed case (small) - 50 nodes) ####
source("./scripts/table_h4.R")

## Table H5 (Table, mixed case (large) - 10 nodes) ####
source("./scripts/table_h5.R")

## Figure K2 (Graphs, nominal-level only - 30 nodes) ####
source("./scripts/figure_k2.R")

## Figure K3 (Graphs, mixed case (small) - 10 nodes) ####
source("./scripts/figure_k3.R")

## Figure F4 (Graphs, mixed case (large) - 50 nodes) ####
source("./scripts/figure_k4.R")

## Figure F5 and Figure K6 (Graph, HCC original and trimmed graph) ####
source("./scripts/figure_k5_and_k6.R")
